/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */
  function init(){
            setTimeout(function(){
                $.mobile.changePage("#intro1");
            },1000);
        }
        var insertToken ="";
           $(document).ready(function(){
            var addr = "http://dacham.xyz/";//태기형 스프링 
            var addr2 = "http://106.249.38.115:8080/dacham/"; //재웅
            var addr3 = "http://210.101.229.130:8080/dacham/" //교수회관
            var addrLocal = "http://localhost:8080/dacham/";
                //$("#logo").click(function(){window.location.href="http://106.249.38.73:8080/dacham"});
                $(document).on("click","#mHome", function(){                    
                    $('#i').attr('src', addr);                    
                 }); 

                 $(document).on("click","#loginConnect", function(){   //로그인                 
                  var id = $("#id").val();
                  var passwd=$("#passwd").val();
                  
                  $.ajax({
                      data:{"id":id,"passwd":passwd},
                      jsonpCallback:"callback",
                      type:"get",
                      dataType:"jsonp",
                      url: addr+"mLogin",
                      success:function(result){
                          if(result==1){
                            alert("로그인 성공");
                            $("#login").hide();                           
                            $("#mLogin").attr("data-rel","");
                            $("#mLogin").attr("href","#");
                            $("#mLogin").attr("data-icon","action");
                            $("#mLogin").attr("data-position-to","");                            
                            $("#mLogin").text("로그아웃");
                            $("#mLogin").attr("id","logout");
                            $("#loginSwitch").val("on");                          
                            $('#i').attr('src', addr);

                          }else if(result==3){
                           alert("도매상 로그인 성공");
                            $("#login").hide();                           
                            $("#mLogin").attr("data-rel","");
                            $("#mLogin").attr("href","#");
                            $("#mLogin").attr("data-icon","action");
                            $("#mLogin").attr("data-position-to","");                            
                            $("#mLogin").text("로그아웃");
                            $("#mLogin").attr("id","logout");
                            $("#loginSwitch").val("on");                          
                            $('#i').attr('src', addr+"wholesaler");
                        }else{
                              alert("아이디 또는 비밀번호가 틀립니다.");
                          }
                      }
                      
                  });

                  
                  
                 // alert("인설트토큰:"+insertToken);
                  var data = {"id":id,
                                "token":insertToken
                    }
                    $.ajax({
                        jsonpCallback:"callback",
                        type:"get",
                        dataType:"jsonp",
                        data : data,
                        url: addr+"insertToken",
                        success:function(result){
                            //alert("토큰 들어감:"+result);
                        }
                    });
                                  
                 });  
                  $(document).on("click","#logout", function(){   //로그아웃         
                 
                  $.ajax({                      
                      jsonpCallback:"callback",
                      type:"get",
                      dataType:"jsonp",
                      url:addr+"mLogout",
                      success:function(result){
                          if(result=1){
                            alert("로그아웃 되었습니다.");
                            $("#logout").attr("href","#login");
                            $("#logout").attr("data-rel","popup");
                            $("#logout").attr("data-icon","power");                           
                            $("#logout").attr("data-position-to","window");
                            $("#logout").text("로그인"); 
                            $("#logout").attr("id","mLogin"); 
                             $("#login").show(); 
                             $("#loginSwitch").val("off");                                                         
                            $('#i').attr('src', addr);

                          }else{                             
                          }
                      }
                      
                  });                  
                 });

                 $(document).on("click","#mInfo", function(){ //마이페이지
                    if($("#loginSwitch").val()=="off"){
                        alert("로그인 후에 이용해주세요.");
                    }else{
                        $('#i').attr('src', addr+"myPage?status=0"); 
                    }
                 });
                  
            });

document.addEventListener("deviceready", onDeviceReady, false);

function onDeviceReady() {
    
	//alert(FCMPlugin)
	FCMPlugin.getToken(
	  function(token){
		console.log("token :"+ token)
		//alert("token : "+ token);
        insertToken = token;
	  },
	  function(err){
		console.log('error retrieving token: ' + err);
	  }
	)

	FCMPlugin.onNotification(

	  function(data){
		if(data.wasTapped){
		  //alert( JSON.stringify(data) );
		}else{
		 // alert( JSON.stringify(data) );
		}
	  },
	  function(msg){
		//alert('onNotification callback successfully registered: ' + msg)
		console.log('onNotification callback successfully registered: ' + msg);
	  },
	  function(err){
		console.log('Error registering onNotification callback: ' + err);
	  }
	);
}